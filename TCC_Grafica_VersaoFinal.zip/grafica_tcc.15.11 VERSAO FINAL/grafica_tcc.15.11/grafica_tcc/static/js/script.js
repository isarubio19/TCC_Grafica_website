// Função para carregar produtos na página inicial
let produtosJaCarregados = false;


async function carregarProdutos() {
    const productList = document.getElementById('product-list');
    if (!productList) {
        console.error("Elemento 'product-list' não encontrado na página.");
        return;
    }

    // 1. Limpa COMPLETAMENTE a lista antes de qualquer outra coisa.
    productList.innerHTML = '';

    try {
        const response = await fetch('/api/produtos');
        if (!response.ok) {
            throw new Error(`Erro na rede: ${response.status}`);
        }
        const produtos = await response.json();

        if (produtos.length === 0) {
            productList.innerHTML = '<p>Nenhum produto encontrado no momento.</p>';
            return;
        }


produtos.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card';

        // 1. Converte o nome do produto para um nome de arquivo válido
        const nomeArquivo = p.nome.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    
        // 2. Monta o caminho da imagem, assumindo que a extensão é .jpg
        const caminhoImagem = `/static/images/${nomeArquivo}.jpg`;

        // 3. Cria a tag <img> usando o caminho gerado
        const img = document.createElement('img');
        img.src = caminhoImagem;
        img.alt = p.nome;
        img.className = 'product-image';

        //FIM DA LÓGICA DA IMAGEM
        

        const title = document.createElement('h3');
        title.textContent = p.nome;

        const description = document.createElement('p');
        description.textContent = p.descricao;

        const price = document.createElement('p');
        price.innerHTML = `<strong>A partir de: R$ ${Number(p.preco_base).toFixed(2)} por unidade </strong>`;

        const button = document.createElement('button');
        button.className = 'btn-pedir';
        button.textContent = 'Selecionar Produto';
        button.textContent = 'Selecionar Produto'; // Garante que o texto do botão esteja correto
        button.onclick = () => {
            // Redireciona o navegador para uma nova página, passando o ID do produto na URL
            window.location.href = `/personalizar/${p.id}`;
};


        // Adiciona os elementos ao card 
        // ... (criação dos elementos img, title, description, etc.)

        card.appendChild(title);       // 1º: Título (ex: "Folhetos")
        card.appendChild(description); // 2º: Descrição
        card.appendChild(img);         // 3º: Imagem
        card.appendChild(price);       // 4º: Preço
        card.appendChild(button);      // 5º: Botão

        productList.appendChild(card);

    });


    } catch (error) {
        console.error('Falha grave ao carregar produtos:', error);
        productList.innerHTML = '<p>Ocorreu um erro ao carregar os produtos.</p>';
    }
}


// Garante que a função seja chamada quando a página de produtos carregar
//document.addEventListener('DOMContentLoaded', () => {
    //if (document.getElementById('product-list')) {
    //    carregarProdutos();
   /// }
//});

// Função para configurar o formulário de cadastro
function setupCadastroForm() {
    const form = document.getElementById('cadastro-form');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        const response = await fetch('/api/cadastro', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        const messageEl = form.querySelector('.message');
        if (response.ok) {
            messageEl.textContent = result.mensagem;
            messageEl.style.color = 'green';
            setTimeout(() => window.location.href = '/login', 2000);
        } else {
            messageEl.textContent = `Erro: ${result.erro}`;
            messageEl.style.color = 'red';
        }
    });
}

// Função para configurar o formulário de login
function setupLoginForm() {
    const form = document.getElementById('login-form');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        const messageEl = form.querySelector('.message');
        if (response.ok) {
            window.location.href = '/dashboard';
        } else {
            messageEl.textContent = `Erro: ${result.erro}`;
            messageEl.style.color = 'red';
        }
    });
}

// Função para carregar pedidos no dashboard
async function carregarPedidos() {
    const response = await fetch('/api/pedidos');
    if (response.status === 401) {
        window.location.href = '/login';
        return;
    }
    const pedidos = await response.json();
    const container = document.getElementById('order-list');
    container.innerHTML = '';
    if (pedidos.length === 0) {
        container.innerHTML = '<p>Você ainda não fez nenhum pedido.</p>';
        return;
    }
    pedidos.forEach(p => {
    // Formata a data para exibição
    const dataFormatada = p.data_pedido ? new Date(p.data_pedido).toLocaleDateString('pt-BR') : 'N/A';
    
    container.innerHTML += `
        <div class="order-card">
            <h3>Pedido #${p.id}</h3>
            <p><strong>Produto:</strong> ${p.produto}</p>
            <p><strong>Quantidade:</strong> ${p.quantidade}</p>
            <p><strong>Status:</strong> ${p.status_pedido}</p>
            <p><strong>Data:</strong> ${dataFormatada}</p>
        </div>
    `;
});

}

// Função para configurar o botão de logout
function setupLogoutButton() {
    const btn = document.getElementById('logout-btn');
    if (btn) {
        btn.addEventListener('click', async () => {
            await fetch('/api/logout', { method: 'POST' });
            window.location.href = '/login';
        });
    }
}

// Adicione esta nova função ao seu arquivo script.js
async function adicionarAoCarrinho(produtoId) {
    try {
        // 1. Envia o ID do produto para a nova API no backend
        const response = await fetch('/api/carrinho/adicionar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ produto_id: produtoId }),
        });

        const result = await response.json();

        if (response.ok) {
            // 2. Mostra uma mensagem de sucesso para o usuário
            alert(result.mensagem); // Ex: "Produto adicionado ao carrinho!"
            // Opcional: Atualizar um ícone de carrinho no cabeçalho, etc.
        } else {
            // Se o usuário não estiver logado, o backend retornará um erro
            if (response.status === 401) {
                alert('Você precisa fazer login para adicionar produtos ao carrinho.');
                window.location.href = '/login'; // Redireciona para a página de login
            } else {
                throw new Error(result.erro || 'Falha ao adicionar produto.');
            }
        }
    } catch (error) {
        console.error('Erro ao adicionar ao carrinho:', error);
        alert(error.message);
    }
}

// --- Lógica das Abas ---
const tabButtons = document.querySelectorAll('.tab-button');
const tabPanes = document.querySelectorAll('.tab-pane');

tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Remove a classe 'active' de todos os botões e painéis
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabPanes.forEach(pane => pane.classList.remove('active'));

        // Adiciona a classe 'active' ao botão clicado
        button.classList.add('active');

        // Adiciona a classe 'active' ao painel correspondente
        const targetTab = button.getAttribute('data-tab');
        document.getElementById(targetTab).classList.add('active');
    });
});


