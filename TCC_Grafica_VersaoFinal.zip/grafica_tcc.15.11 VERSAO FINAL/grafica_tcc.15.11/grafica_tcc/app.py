import mysql.connector
from flask import Flask, jsonify, request, session, render_template, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename # UPLOAD 

import os

class App:
    def __init__(self, template_folder='templates', static_folder='static'):
        self.app = Flask(__name__, template_folder=template_folder, static_folder=static_folder)
        self.app.secret_key = os.urandom(24)
        self.UPLOAD_FOLDER = 'uploads' # NOVO
        self.app.config['UPLOAD_FOLDER'] = self.UPLOAD_FOLDER # NOVO
        os.makedirs(self.UPLOAD_FOLDER, exist_ok=True) # NOVO

        self.db_config = {
            'host': 'localhost',
            'user': 'root',
            'password': 'root', #senha MySQL 
            'database': 'grafica_system'
        }
        
        self.conn = self.conectar_bd()
        
        # Estas são as únicas chamadas de registro necessárias
        self.registrar_rotas_api()
        self.registrar_rotas_html()

    def conectar_bd(self):
        try:
            conn = mysql.connector.connect(**self.db_config)
            print("Conexao com o banco de dados bem-sucedida!")
            return conn
        except mysql.connector.Error as err:
            print(f"Erro ao conectar ao banco de dados: {err}")
            return None

    
    # UMA ÚNICA FUNÇÃO PARA REGISTRAR ROTAS DE API
    
    def registrar_rotas_api(self):
        """Registra os endpoints que retornam dados (JSON)."""
        self.app.route('/api/cadastro', methods=['POST'])(self.cadastrar_cliente)
        self.app.route('/api/login', methods=['POST'])(self.login)
        self.app.route('/api/logout', methods=['POST'])(self.logout)
        self.app.route('/api/pedidos', methods=['GET'])(self.listar_pedidos_usuario)
        self.app.route('/api/produtos', methods=['GET'])(self.listar_produtos)
        # A rota do carrinho foi comentada pois a lógica mudou, mas pode ser reativada no futuro
        # self.app.route('/api/adicionar-carrinho', methods=['POST'])(self.adicionar_ao_carrinho)

    #  UMA ÚNICA FUNÇÃO PARA REGISTRAR ROTAS HTML
    def registrar_rotas_html(self):
        """Registra as rotas que servem as páginas HTML para o navegador."""
        self.app.route('/')(self.pagina_inicial)
        self.app.route('/login')(self.pagina_login)
        self.app.route('/cadastro')(self.pagina_cadastro)
        self.app.route('/dashboard')(self.pagina_dashboard)
        self.app.route('/produtos')(self.pagina_produtos)
        self.app.route('/pedido_sucesso')(self.pedido_sucesso)  #NOVA ROTA 


        # --- ROTAS DOS SERVIÇOS ---
        self.app.route('/servicos/pre-impressao')(self.pagina_pre_impressao)
        self.app.route('/servicos/impressao')(self.pagina_impressao)
        self.app.route('/servicos/acabamento')(self.pagina_acabamento)
        self.app.route('/servicos/outros')(self.pagina_outros_servicos)
        
        # --- ROTA DE PERSONALIZAÇÃO  ---
        self.app.route('/personalizar/<int:produto_id>')(self.pagina_personalizar_produto)
        self.app.route('/finalizar-pedido', methods=['POST'])(self.finalizar_pedido)
        self.app.route('/pedido_sucesso')(self.pedido_sucesso)

    def run(self, host='127.0.0.1', port=5000, debug=True):
        if not self.conn:
            print("Aplicacao encerrada. Falha na conexao com o banco de dados.")
            return
        self.app.run(host=host, port=port, debug=debug)

    # --- FUNÇÕES QUE RENDERIZAM AS PÁGINAS HTML ---
    def pagina_inicial(self): return render_template('index.html')
    def pagina_login(self): return render_template('login.html')
    def pagina_cadastro(self): return render_template('cadastro.html')
    def pagina_dashboard(self):
        if 'usuario_id' not in session: return redirect(url_for('pagina_login'))
        return render_template('dashboard.html', nome_usuario=session.get('nome_usuario'))
    def pagina_produtos(self): return render_template('produtos.html')

    def pagina_pre_impressao(self): return render_template('pre-impressao.html')
    def pagina_impressao(self): return render_template('impressao.html')
    def pagina_acabamento(self): return render_template('acabamento.html')
    def pagina_outros_servicos(self): return render_template('outros-servicos.html')
    
    # FUNÇÃO DE PERSONALIZAÇÃO 
    def pagina_personalizar_produto(self, produto_id):
        try:
            cursor = self.conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM produtos WHERE id = %s AND ativo = TRUE", (produto_id,))
            produto = cursor.fetchone()
            cursor.close()
            if not produto:
                return redirect(url_for('pagina_produtos'))
            return render_template('personalizar.html', produto=produto)
        except Exception as e:
            print(f"Erro ao buscar produto para personalização: {e}")
            return redirect(url_for('pagina_produtos'))

    #FUNÇÕES DA API
    def cadastrar_cliente(self):
        dados = request.get_json()
        senha_hash = generate_password_hash(dados['senha'])
        cursor = self.conn.cursor()
        try:
            query = "INSERT INTO usuarios (nome, email, senha_hash) VALUES (%s, %s, %s)"
            cursor.execute(query, (dados['nome'], dados['email'], senha_hash))
            self.conn.commit()
            return jsonify({'mensagem': 'Cliente cadastrado com sucesso!'}), 201
        except mysql.connector.Error:
            self.conn.rollback()
            return jsonify({'erro': 'Este e-mail já está em uso.'}), 409
        finally: cursor.close()

    def login(self):
        dados = request.get_json()
        cursor = self.conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM usuarios WHERE email = %s AND ativo = TRUE", (dados['email'],))
        usuario = cursor.fetchone()
        cursor.close()
        if usuario and check_password_hash(usuario['senha_hash'], dados['senha']):
            session['usuario_id'] = usuario['id']
            session['nome_usuario'] = usuario['nome']
            return jsonify({'mensagem': 'Login bem-sucedido!'}), 200
        return jsonify({'erro': 'Credenciais inválidas'}), 401

    def logout(self):
        session.clear()
        return jsonify({'mensagem': 'Logout bem-sucedido!'}), 200

    def listar_pedidos_usuario(self):
        if 'usuario_id' not in session: return jsonify({'erro': 'Acesso não autorizado'}), 401
        
        # Garante que a conexão está ativa
        if not self.conn or not self.conn.is_connected():
            self.conn = self.conectar_bd()
            if not self.conn:
                return jsonify({'erro': 'Falha na conexão com o banco de dados.'}), 500

        cursor = self.conn.cursor(dictionary=True)
        query = """
            SELECT p.id, prod.nome as produto, p.quantidade, p.status_pedido, p.data_pedido
            FROM pedidos p JOIN produtos prod ON p.produto_id = prod.id
            WHERE p.usuario_id = %s ORDER BY p.data_pedido DESC
        """
        try:
            cursor.execute(query, (session['usuario_id'],))
            pedidos = cursor.fetchall()
            return jsonify(pedidos), 200
        except mysql.connector.Error as err:
            print(f"Erro ao listar pedidos: {err}")
            return jsonify({'erro': 'Falha ao buscar pedidos no banco de dados.'}), 500
        finally:
            cursor.close()

    def listar_produtos(self):
        try:
            cursor = self.conn.cursor(dictionary=True)
            cursor.execute("SELECT id, nome, descricao, preco_base FROM produtos WHERE ativo = TRUE")
            produtos = cursor.fetchall()
            cursor.close()
            return jsonify(produtos), 200
        except Exception as e:
            print(f"ERRO GRAVE ao listar produtos: {e}")
            return jsonify({"erro": "Falha interna ao buscar produtos"}), 500

    # A função adicionar_ao_carrinho não é mais usada nesta lógica, mas a mantemos aqui para o futuro
    def adicionar_ao_carrinho(self):
        if 'usuario_id' not in session:
            return jsonify({'erro': 'Acesso não autorizado. Faça o login.'}), 401
        dados = request.get_json()
        produto_id = dados.get('produto_id')
        usuario_id = session['usuario_id']
        if not produto_id:
            return jsonify({'erro': 'ID do produto não fornecido.'}), 400
        try:
            cursor = self.conn.cursor()
            query = """
                INSERT INTO pedidos (usuario_id, produto_id, quantidade, status_pedido)
                VALUES (%s, %s, 1, 'orcamento')
            """
            cursor.execute(query, (usuario_id, produto_id))
            self.conn.commit()
            cursor.close()
            return jsonify({'mensagem': 'Produto adicionado ao carrinho com sucesso!'}), 201
        except mysql.connector.Error as err:
            self.conn.rollback()
            print(f"Erro ao adicionar ao carrinho: {err}")
            return jsonify({'erro': 'Falha ao adicionar produto ao carrinho.'}), 500
    def pedido_sucesso(self):
        # Rota para exibir a página de sucesso do pedido
        return render_template('pedido_sucesso.html')

 
    def finalizar_pedido(self):
        # Verifica se o usuário está logado
        if 'usuario_id' not in session:
            # Se não estiver logado, redireciona para a página de login
            return redirect(url_for('pagina_login'))

        # Esta rota processa o formulário e redireciona para a página de sucesso
        if request.method == 'POST':

            caminho_arquivo = None
            if 'arquivo_arte' in request.files:
                arquivo = request.files['arquivo_arte']
                if arquivo.filename != '':
                    # Garante um nome de arquivo seguro
                    nome_arquivo = secure_filename(arquivo.filename)
                    # Cria um nome único para evitar colisões
                    nome_arquivo_unico = f"{session['usuario_id']}_{os.urandom(8).hex()}_{nome_arquivo}"
                    caminho_arquivo = os.path.join(self.app.config['UPLOAD_FOLDER'], nome_arquivo_unico)
                    arquivo.save(caminho_arquivo)
                    print(f"Arquivo salvo em: {caminho_arquivo}")

                
            print("Pedido recebido e processado com sucesso!")
            
            # *** MUDANÇA PRINCIPAL: REDIRECIONA PARA A NOVA PÁGINA ***
            return redirect(url_for('pedido_sucesso'))
        
        return redirect(url_for('pagina_inicial'))


# --- Ponto de Entrada da Aplicação ---
if __name__ == '__main__':
    grafica_app = App()
    grafica_app.run(debug=True)
