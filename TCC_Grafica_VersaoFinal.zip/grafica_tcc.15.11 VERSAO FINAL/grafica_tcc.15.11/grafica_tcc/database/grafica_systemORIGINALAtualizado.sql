-- Esquema do Banco de Dados para Sistema de Gestão de Gráfica
-- Baseado nos requisitos funcionais do TCC

CREATE DATABASE IF NOT EXISTS grafica_system;
USE grafica_system;

-- Tabela de Usuários (Clientes e Administradores)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    cpf_cnpj VARCHAR(20) UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    tipo_usuario ENUM('cliente', 'administrador') DEFAULT 'cliente',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de Categorias de Produtos/Serviços
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de Produtos/Serviços
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco_base DECIMAL(10,2) NOT NULL,
    prazo_producao_dias INT DEFAULT 5,
    especificacoes_tecnicas JSON,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Tabela de Materiais
CREATE TABLE materiais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    tipo VARCHAR(50),
    preco_por_unidade DECIMAL(10,4),
    unidade_medida VARCHAR(20),
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de Acabamentos
CREATE TABLE acabamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco_adicional DECIMAL(10,2) DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de Pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    material_id INT,
    acabamento_id INT,
    tamanho VARCHAR(50),
    observacoes TEXT,
    valor_orcamento DECIMAL(10,2),
    status_pedido ENUM('orcamento', 'aprovado', 'em_producao', 'pre_impressao', 'impressao', 'acabamento', 'finalizado', 'entregue', 'cancelado') DEFAULT 'orcamento',
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_aprovacao TIMESTAMP NULL,
    data_entrega_prevista DATE,
    data_entrega_real DATE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (produto_id) REFERENCES produtos(id),
    FOREIGN KEY (material_id) REFERENCES materiais(id),
    FOREIGN KEY (acabamento_id) REFERENCES acabamentos(id)
);

-- Tabela de Arquivos do Pedido
CREATE TABLE arquivos_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    caminho_arquivo VARCHAR(500) NOT NULL,
    tipo_arquivo VARCHAR(50),
    tamanho_arquivo BIGINT,
    data_upload TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
);

-- Tabela de Histórico de Status do Pedido
CREATE TABLE historico_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    status_anterior VARCHAR(50),
    status_novo VARCHAR(50) NOT NULL,
    observacoes TEXT,
    usuario_alteracao INT,
    data_alteracao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (usuario_alteracao) REFERENCES usuarios(id)
);

-- Inserção de dados iniciais

-- Categorias
INSERT INTO categorias (nome, descricao) VALUES
('Impressão Digital', 'Serviços de impressão digital em diversos formatos'),
('Impressão Offset', 'Impressão offset para grandes tiragens'),
('Acabamento', 'Serviços de acabamento e pós-impressão'),
('Encadernação', 'Serviços de encadernação e montagem');

-- Materiais
INSERT INTO materiais (nome, tipo, preco_por_unidade, unidade_medida) VALUES
('Papel Sulfite 75g', 'papel', 0.05, 'folha'),
('Papel Couché 115g', 'papel', 0.12, 'folha'),
('Papel Couché 170g', 'papel', 0.18, 'folha'),
('Papel Fotográfico', 'papel', 0.25, 'folha'),
('Cartão 300g', 'cartao', 0.30, 'folha');

-- Acabamentos
INSERT INTO acabamentos (nome, descricao, preco_adicional) VALUES
('Sem acabamento', 'Apenas impressão', 0.00),
('Plastificação', 'Plastificação fosca ou brilhante', 2.50),
('Verniz UV', 'Aplicação de verniz UV', 3.00),
('Dobra simples', 'Dobra ao meio', 0.50),
('Dobra dupla', 'Dobra em três partes', 1.00),
('Grampeação', 'Grampos no centro', 1.50),
('Encadernação espiral', 'Encadernação com espiral', 5.00);

-- Produtos
INSERT INTO produtos (categoria_id, nome, descricao, preco_base, prazo_producao_dias) VALUES
(1, 'Folhetos', 'Folhetos personalizados em diversos tamanhos e tipos de papel', 1.50, 2),
(1, 'Catálogos', 'Catálogos de produtos com acabamento profissional para sua empresa.', 9.50, 8),
(1, 'Revistas', 'Impressão de revistas com alta qualidade de cor e encadernação.', 12.00, 10),
(2, 'Livros', 'Produção de livros sob demanda com capa personalizada e miolo em papel pólen.', 25.00, 15),
(3, 'Agendas', 'Agendas personalizadas para 2026, com capa dura e acabamento em espiral.', 8.50, 7),
(4, 'Adesivos', 'Adesivos em vinil ou papel, com corte especial para rótulos e brindes.', 9.00, 3);


-- Usuário administrador padrão
INSERT INTO usuarios (nome, email, senha_hash, tipo_usuario) VALUES
('Administrador', 'admin@grafica.com', '$2b$12$LQv3c1yqBwEHFNn5E5gISOhGEuuC9QM/0ScQHNCC/thaLgLXhluwW', 'administrador');
-- Senha: admin123

-- 1. Adicionar a coluna de celular (se o campo 'telefone' não for o celular)
ALTER TABLE usuarios ADD COLUMN celular VARCHAR(20) AFTER telefone;

-- 2. Adicionar as colunas de endereço
ALTER TABLE usuarios ADD COLUMN cep VARCHAR(10) AFTER cpf_cnpj;
ALTER TABLE usuarios ADD COLUMN endereco_completo VARCHAR(255) AFTER cep;
ALTER TABLE usuarios ADD COLUMN cidade VARCHAR(100) AFTER endereco_completo;
ALTER TABLE usuarios ADD COLUMN estado VARCHAR(100) AFTER cidade;

